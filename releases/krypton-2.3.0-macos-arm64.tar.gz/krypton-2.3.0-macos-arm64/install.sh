#!/usr/bin/env bash
# Krypton macOS installer — copies the bundle, signs it, puts kcc on PATH.
set -euo pipefail
PREFIX="${1:-/usr/local/krypton}"
BIN="${BINDIR:-/usr/local/bin}"
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SUDO=""; [[ -w "$(dirname "$PREFIX")" && -w "$(dirname "$BIN")" ]] || SUDO="sudo"
echo "installing Krypton to $PREFIX ..."
$SUDO rm -rf "$PREFIX"; $SUDO mkdir -p "$PREFIX"; $SUDO cp -R "$HERE"/. "$PREFIX"/
# Clear download quarantine + ad-hoc sign so AMFI lets the binaries run.
$SUDO xattr -dr com.apple.quarantine "$PREFIX" 2>/dev/null || true
for b in bootstrap/kcc_driver_macos_aarch64 compiler/macos_arm64/kcc-arm64 \
         compiler/macos_arm64/macho_host compiler/macos_arm64/kls; do
    [[ -e "$PREFIX/$b" ]] && $SUDO codesign -s - -f "$PREFIX/$b" 2>/dev/null || true
done
# Stamp binaries newer than the .k sources so ensureHost() skips the clang rebuild.
$SUDO touch "$PREFIX/bootstrap/kcc_driver_macos_aarch64" \
            "$PREFIX/compiler/macos_arm64/kcc-arm64" \
            "$PREFIX/compiler/macos_arm64/macho_host" 2>/dev/null || true
$SUDO mkdir -p "$BIN"
$SUDO ln -sf "$PREFIX/bootstrap/kcc_driver_macos_aarch64" "$BIN/kcc"
[[ -e "$PREFIX/compiler/macos_arm64/kls" ]] && $SUDO ln -sf "$PREFIX/compiler/macos_arm64/kls" "$BIN/kls"
echo "done. 'kcc --version':"; "$BIN/kcc" --version
