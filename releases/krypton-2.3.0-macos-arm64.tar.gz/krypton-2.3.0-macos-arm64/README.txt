Krypton 2.3.0 — macOS arm64
Install:  ./install.sh            (symlinks kcc into /usr/local/bin, ad-hoc signs)
Use:      kcc hello.k -o hello && ./hello
          kcc -r hello.ks
          kcc --version
No clang, no clone needed — prebuilt binaries, self-signed on install.
