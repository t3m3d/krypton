Krypton 2.3.0 — Linux x86_64
Install:  ./install.sh            (symlinks kcc into /usr/local/bin)
Use:      kcc hello.k -o hello && ./hello
          kcc --aarch64 hello.k -o hello   (cross-compile to aarch64 ELF)
          kcc --version
No C compiler, no clone needed — prebuilt static binaries.
