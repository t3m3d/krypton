#!/usr/bin/env bash
# Krypton Linux installer — symlinks kcc into PATH. No build, no C.
set -euo pipefail
PREFIX="${1:-/usr/local/krypton}"
BIN="${BINDIR:-/usr/local/bin}"
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ARCH=$(uname -m); [[ "$ARCH" == "amd64" ]] && ARCH=x86_64
SUDO=""; [[ -w "$(dirname "$PREFIX")" && -w "$(dirname "$BIN")" ]] || SUDO="sudo"
echo "installing Krypton to $PREFIX ..."
$SUDO rm -rf "$PREFIX"; $SUDO mkdir -p "$PREFIX"; $SUDO cp -R "$HERE"/. "$PREFIX"/
$SUDO mkdir -p "$BIN"
$SUDO ln -sf "$PREFIX/bootstrap/kcc_driver_linux_${ARCH}" "$BIN/kcc"
echo "done. 'kcc --version':"; KRYPTON_ROOT="$PREFIX" "$BIN/kcc" --version
